export const MenuItems = [
  {
    title: 'Sells Admin',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'Product Info',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'User Master',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'Log Out',
    url: '#',
    cName: 'nav-links-mobile',
  },
]
