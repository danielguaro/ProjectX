import React from 'react'
import Navbar from './Navbar/Navbar'
import Ventas from './Main/main'

function Venta() {
  return (
    <div>
      <Navbar />
      <Ventas />
    </div>
  )
}

export default Venta