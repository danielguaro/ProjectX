import React from 'react'
import ProductReg from './Sells Admin/Venta'

function App() {
  return (
    <div>
      <ProductReg />
    </div>
  )
}

export default App
